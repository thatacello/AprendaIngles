package br.infnet.aprendaingles;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.doubleclick.PublisherAdRequest;
import com.google.android.gms.ads.doubleclick.PublisherAdView;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import static com.google.android.gms.ads.RequestConfiguration.TAG_FOR_CHILD_DIRECTED_TREATMENT_TRUE;

public class Transporte extends AppCompatActivity {

    private ImageButton voltar;
    private ImageButton btnCar;
    private ImageButton btnTruck;
    private ImageButton btnTrain;
    private ImageButton btnBoat;
    private ImageButton btnShip;
    private ImageButton btnAirplane;

    private MediaPlayer mediaPlayer;

    private AdView AdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transporte);

        voltar = findViewById(R.id.voltarId);
        btnCar = findViewById(R.id.btnCar);
        btnTruck = findViewById(R.id.btnTruck);
        btnTrain = findViewById(R.id.btnTrain);
        btnBoat = findViewById(R.id.btnBoat);
        btnShip = findViewById(R.id.btnShip);
        btnAirplane = findViewById(R.id.btnAirplane);
        AdView = findViewById(R.id.publisherAdView);

        AdView adView = new AdView(this);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId("ca-app-pub-7927458969649246/6772443948");

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
                RequestConfiguration requestConfiguration = MobileAds.getRequestConfiguration()
                        .toBuilder()
                        .setTagForChildDirectedTreatment(TAG_FOR_CHILD_DIRECTED_TREATMENT_TRUE)
                        .build();
            }
        });

        AdRequest adRequest = new AdRequest.Builder().build();
        AdView.loadAd(adRequest);

        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Transporte.this, MainActivity.class);
                startActivity(i);
                finish();
            }
        });

        btnCar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(Transporte.this, R.raw.car);
                executarSom();
            }
        });

        btnTruck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(Transporte.this, R.raw.truck);
                executarSom();
            }
        });

        btnTrain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(Transporte.this, R.raw.train);
                executarSom();
            }
        });

        btnBoat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(Transporte.this, R.raw.boat);
                executarSom();
            }
        });

        btnShip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(Transporte.this, R.raw.ship);
                executarSom();
            }
        });

        btnAirplane.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(Transporte.this, R.raw.airplane);
                executarSom();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        AdView.resume();
    }

    @Override
    public void onPause() {
        AdView.pause();

        super.onPause();
    }

    public void executarSom (){
        if (mediaPlayer != null){
            mediaPlayer.start();

            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mediaPlayer.release();
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        AdView.destroy();

        super.onDestroy();
        if(mediaPlayer != null){
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}
