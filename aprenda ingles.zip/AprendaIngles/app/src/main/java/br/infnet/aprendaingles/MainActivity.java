package br.infnet.aprendaingles;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.doubleclick.PublisherAdRequest;
import com.google.android.gms.ads.doubleclick.PublisherAdView;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import static com.google.android.gms.ads.RequestConfiguration.TAG_FOR_CHILD_DIRECTED_TREATMENT_TRUE;

public class MainActivity extends AppCompatActivity {

    private ImageButton animais;
    private ImageButton cores;
    private ImageButton escola;
    private ImageButton formas;
    private ImageButton frutas;
    private ImageButton numeros;
    private ImageButton transportes;
    private ImageButton vegetais;

    private MediaPlayer mediaPlayer;
    private MediaPlayer mediaPlayer2;

    private AdView AdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        animais = findViewById(R.id.animaisId);
        cores = findViewById(R.id.coresId);
        escola = findViewById(R.id.escolaId);
        formas = findViewById(R.id.formasId);
        frutas = findViewById(R.id.frutasId);
        numeros = findViewById(R.id.numerosId);
        transportes = findViewById(R.id.transportesId);
        vegetais = findViewById(R.id.vegetaisId);
        AdView = findViewById(R.id.publisherAdView);

        AdView adView = new AdView(this);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId("ca-app-pub-7927458969649246/6772443948");

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {

            }
        });

        AdRequest adRequest = new AdRequest.Builder().build();
        AdView.loadAd(adRequest);

        RequestConfiguration requestConfiguration = MobileAds.getRequestConfiguration()
                .toBuilder()
                .setTagForChildDirectedTreatment(TAG_FOR_CHILD_DIRECTED_TREATMENT_TRUE)
                .build();

        mediaPlayer2 = MediaPlayer.create(MainActivity.this, R.raw.happydreams);
        if (mediaPlayer2 != null){
            mediaPlayer2.start();

            mediaPlayer2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mediaPlayer2.release();
                }
            });
        }

        animais.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(MainActivity.this, R.raw.animals);
                executarSom();
                Intent i = new Intent(MainActivity.this, Bichos.class);
                startActivity(i);
                mediaPlayer2.stop();
            }
        });

        cores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(MainActivity.this, R.raw.colors);
                executarSom();
                Intent i = new Intent(MainActivity.this, Cores.class);
                startActivity(i);
                mediaPlayer2.stop();
            }
        });

        escola.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(MainActivity.this, R.raw.schoolsupplies);
                executarSom();
                Intent i = new Intent(MainActivity.this, Escola.class);
                startActivity(i);
                mediaPlayer2.stop();
            }
        });

        formas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(MainActivity.this, R.raw.shapes);
                executarSom();
                Intent i = new Intent(MainActivity.this, Formas.class);
                startActivity(i);
                mediaPlayer2.stop();
            }
        });

        frutas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(MainActivity.this, R.raw.fruits);
                executarSom();
                Intent i = new Intent(MainActivity.this, Frutas.class);
                startActivity(i);
                mediaPlayer2.stop();
            }
        });

        numeros.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(MainActivity.this, R.raw.numbers);
                executarSom();
                Intent i = new Intent(MainActivity.this, Numeros.class);
                startActivity(i);
                mediaPlayer2.stop();
            }
        });

        transportes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(MainActivity.this, R.raw.transport);
                executarSom();
                Intent i = new Intent(MainActivity.this, Transporte.class);
                startActivity(i);
                mediaPlayer2.stop();
            }
        });

        vegetais.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(MainActivity.this, R.raw.vegetables);
                executarSom();
                Intent i = new Intent(MainActivity.this, Vegetais.class);
                startActivity(i);
                mediaPlayer2.stop();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        AdView.resume();
    }

    @Override
    public void onPause() {
        AdView.pause();

        super.onPause();
    }

    public void executarSom (){
        if (mediaPlayer != null){
            mediaPlayer.start();

            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mediaPlayer.release();
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        AdView.destroy();

        super.onDestroy();
        if(mediaPlayer != null || mediaPlayer2 != null){
            mediaPlayer.release();
            mediaPlayer2.release();
            mediaPlayer = null;
            mediaPlayer2 = null;
        }
    }
}
