package br.infnet.aprendaingles;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.doubleclick.PublisherAdRequest;
import com.google.android.gms.ads.doubleclick.PublisherAdView;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import static com.google.android.gms.ads.RequestConfiguration.TAG_FOR_CHILD_DIRECTED_TREATMENT_TRUE;

public class Formas extends AppCompatActivity {

    private ImageButton voltar;
    private ImageButton btnSquare;
    private ImageButton btnCircle;
    private ImageButton btnRectangle;
    private ImageButton btnTriangle;
    private ImageButton btnHeart;
    private ImageButton btnStar;

    private MediaPlayer mediaPlayer;

    private AdView AdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formas);

        voltar = findViewById(R.id.voltarId);
        btnSquare = findViewById(R.id.btnSquare);
        btnCircle = findViewById(R.id.btnCircle);
        btnRectangle = findViewById(R.id.btnRectangle);
        btnTriangle = findViewById(R.id.btnTriangle);
        btnHeart = findViewById(R.id.btnHeart);
        btnStar = findViewById(R.id.btnStar);
        AdView = findViewById(R.id.publisherAdView);

        AdView adView = new AdView(this);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId("ca-app-pub-7927458969649246/6772443948");

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
                RequestConfiguration requestConfiguration = MobileAds.getRequestConfiguration()
                        .toBuilder()
                        .setTagForChildDirectedTreatment(TAG_FOR_CHILD_DIRECTED_TREATMENT_TRUE)
                        .build();
            }
        });

        AdRequest adRequest = new AdRequest.Builder().build();
        AdView.loadAd(adRequest);

        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Formas.this, MainActivity.class);
                startActivity(i);
                finish();
            }
        });

        btnSquare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(Formas.this, R.raw.square);
                executarSom();
            }
        });

        btnCircle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(Formas.this, R.raw.circle);
                executarSom();
            }
        });

        btnRectangle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(Formas.this, R.raw.rectangle);
                executarSom();
            }
        });

        btnTriangle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(Formas.this, R.raw.triangle);
                executarSom();
            }
        });

        btnHeart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(Formas.this, R.raw.heart);
                executarSom();
            }
        });

        btnStar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer = MediaPlayer.create(Formas.this, R.raw.star);
                executarSom();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        AdView.resume();
    }

    @Override
    public void onPause() {
        AdView.pause();

        super.onPause();
    }

    public void executarSom (){
        if (mediaPlayer != null){
            mediaPlayer.start();

            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mediaPlayer.release();
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        AdView.destroy();

        super.onDestroy();
        if(mediaPlayer != null){
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}
